/*
 Navicat Premium Data Transfer

 Source Server         : Milkin
 Source Server Type    : MySQL
 Source Server Version : 100411 (10.4.11-MariaDB)
 Source Host           : localhost:3306
 Source Schema         : tongchongstreet

 Target Server Type    : MySQL
 Target Server Version : 100411 (10.4.11-MariaDB)
 File Encoding         : 65001

 Date: 11/08/2025 06:45:01
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for access
-- ----------------------------
DROP TABLE IF EXISTS `access`;
CREATE TABLE `access`  (
  `member_id` int UNSIGNED NOT NULL,
  `door_id` int UNSIGNED NOT NULL,
  `center_id` int UNSIGNED NOT NULL,
  `member_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `boss_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `center_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `door_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` int NOT NULL COMMENT '0 - in, 1 - out',
  `status` int NOT NULL COMMENT 'status returned in card api',
  `security_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp,
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  PRIMARY KEY (`member_id`, `center_id`, `created_at`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic PARTITION BY HASH (to_days(`created_at`))
PARTITIONS 10
(PARTITION `p0` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p1` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p2` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p3` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p4` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p5` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p6` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p7` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p8` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 ,
PARTITION `p9` ENGINE = InnoDB MAX_ROWS = 0 MIN_ROWS = 0 )
;

-- ----------------------------
-- Records of access
-- ----------------------------

-- ----------------------------
-- Table structure for ip_list
-- ----------------------------
DROP TABLE IF EXISTS `ip_list`;
CREATE TABLE `ip_list`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ip_list
-- ----------------------------
INSERT INTO `ip_list` VALUES (1, 'ic-wallet-hosting', '116.251.207.229', '2023-04-07 15:16:58', '2025-05-28 13:38:58');
INSERT INTO `ip_list` VALUES (2, 'Simfusion IP', '218.253.137.176', '2023-04-10 15:45:22', '2023-05-29 09:36:42');
INSERT INTO `ip_list` VALUES (3, '8F-WifiReadyGo', '61.244.147.66', '2023-04-10 15:46:55', '2023-04-10 15:50:06');
INSERT INTO `ip_list` VALUES (4, '8F-General Staff', '183.179.161.18', '2023-04-10 15:47:46', '2023-04-10 15:47:46');
INSERT INTO `ip_list` VALUES (5, '8F-Desktop', '183.179.161.22', '2023-04-10 15:48:15', '2023-04-10 15:48:15');
INSERT INTO `ip_list` VALUES (6, '7F-General', '183.178.117.34', '2023-04-10 15:49:02', '2023-04-10 15:49:02');
INSERT INTO `ip_list` VALUES (7, '7F-Gym', '61.92.255.150', '2023-04-10 15:49:30', '2023-04-10 15:49:30');
INSERT INTO `ip_list` VALUES (8, '世貿 IP - 1', '101.78.223.218', '2023-05-09 15:22:21', '2023-05-09 15:22:21');
INSERT INTO `ip_list` VALUES (9, '世貿 IP - 2', '175.45.49.27', '2023-05-09 15:22:39', '2023-05-09 15:22:39');
INSERT INTO `ip_list` VALUES (10, 'SOGO', '59.148.42.234', '2023-05-11 16:31:22', '2023-05-11 16:31:22');
INSERT INTO `ip_list` VALUES (13, 'ic-member-hosting', '116.251.207.232', '2025-05-28 13:39:15', '2025-05-28 13:39:15');
INSERT INTO `ip_list` VALUES (14, 'ic-wallet-hosting-2', '116.251.205.130', '2025-06-14 16:58:42', '2025-06-14 16:58:42');

-- ----------------------------
-- Table structure for permission_role
-- ----------------------------
DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role`  (
  `role_id` int UNSIGNED NOT NULL,
  `permission_id` int UNSIGNED NOT NULL,
  INDEX `role_id_fk_476162`(`role_id` ASC) USING BTREE,
  INDEX `permission_id_fk_476162`(`permission_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permission_role
-- ----------------------------
INSERT INTO `permission_role` VALUES (1, 1);
INSERT INTO `permission_role` VALUES (2, 2);
INSERT INTO `permission_role` VALUES (2, 4);
INSERT INTO `permission_role` VALUES (2, 5);
INSERT INTO `permission_role` VALUES (1, 2);
INSERT INTO `permission_role` VALUES (1, 3);
INSERT INTO `permission_role` VALUES (1, 4);
INSERT INTO `permission_role` VALUES (1, 5);
INSERT INTO `permission_role` VALUES (1, 6);
INSERT INTO `permission_role` VALUES (1, 8);
INSERT INTO `permission_role` VALUES (1, 10);
INSERT INTO `permission_role` VALUES (1, 11);
INSERT INTO `permission_role` VALUES (1, 9);
INSERT INTO `permission_role` VALUES (3, 7);
INSERT INTO `permission_role` VALUES (1, 7);
INSERT INTO `permission_role` VALUES (4, 7);
INSERT INTO `permission_role` VALUES (5, 3);
INSERT INTO `permission_role` VALUES (1, 45);
INSERT INTO `permission_role` VALUES (1, 53);
INSERT INTO `permission_role` VALUES (1, 54);
INSERT INTO `permission_role` VALUES (1, 55);
INSERT INTO `permission_role` VALUES (1, 56);
INSERT INTO `permission_role` VALUES (1, 57);
INSERT INTO `permission_role` VALUES (1, 80);
INSERT INTO `permission_role` VALUES (1, 81);
INSERT INTO `permission_role` VALUES (1, 82);
INSERT INTO `permission_role` VALUES (6, 2);
INSERT INTO `permission_role` VALUES (6, 3);
INSERT INTO `permission_role` VALUES (6, 4);
INSERT INTO `permission_role` VALUES (8, 1);
INSERT INTO `permission_role` VALUES (7, 3);
INSERT INTO `permission_role` VALUES (7, 5);
INSERT INTO `permission_role` VALUES (1, 94);
INSERT INTO `permission_role` VALUES (1, 95);
INSERT INTO `permission_role` VALUES (1, 98);
INSERT INTO `permission_role` VALUES (1, 99);
INSERT INTO `permission_role` VALUES (1, 100);
INSERT INTO `permission_role` VALUES (1, 101);
INSERT INTO `permission_role` VALUES (1, 102);
INSERT INTO `permission_role` VALUES (9, 104);
INSERT INTO `permission_role` VALUES (9, 105);
INSERT INTO `permission_role` VALUES (9, 106);
INSERT INTO `permission_role` VALUES (9, 107);
INSERT INTO `permission_role` VALUES (9, 88);
INSERT INTO `permission_role` VALUES (10, 12);
INSERT INTO `permission_role` VALUES (10, 13);
INSERT INTO `permission_role` VALUES (10, 14);
INSERT INTO `permission_role` VALUES (10, 15);
INSERT INTO `permission_role` VALUES (10, 17);
INSERT INTO `permission_role` VALUES (10, 18);
INSERT INTO `permission_role` VALUES (10, 19);
INSERT INTO `permission_role` VALUES (10, 20);
INSERT INTO `permission_role` VALUES (10, 89);
INSERT INTO `permission_role` VALUES (10, 90);
INSERT INTO `permission_role` VALUES (10, 91);
INSERT INTO `permission_role` VALUES (10, 92);
INSERT INTO `permission_role` VALUES (1, 113);
INSERT INTO `permission_role` VALUES (1, 114);
INSERT INTO `permission_role` VALUES (1, 115);
INSERT INTO `permission_role` VALUES (1, 116);
INSERT INTO `permission_role` VALUES (1, 117);
INSERT INTO `permission_role` VALUES (1, 118);
INSERT INTO `permission_role` VALUES (1, 119);
INSERT INTO `permission_role` VALUES (1, 120);
INSERT INTO `permission_role` VALUES (1, 121);
INSERT INTO `permission_role` VALUES (1, 122);
INSERT INTO `permission_role` VALUES (1, 123);
INSERT INTO `permission_role` VALUES (1, 129);
INSERT INTO `permission_role` VALUES (1, 130);
INSERT INTO `permission_role` VALUES (1, 131);
INSERT INTO `permission_role` VALUES (1, 132);
INSERT INTO `permission_role` VALUES (1, 133);
INSERT INTO `permission_role` VALUES (1, 134);
INSERT INTO `permission_role` VALUES (1, 135);
INSERT INTO `permission_role` VALUES (1, 136);
INSERT INTO `permission_role` VALUES (1, 137);
INSERT INTO `permission_role` VALUES (1, 138);
INSERT INTO `permission_role` VALUES (1, 139);
INSERT INTO `permission_role` VALUES (11, 113);
INSERT INTO `permission_role` VALUES (11, 114);
INSERT INTO `permission_role` VALUES (11, 115);
INSERT INTO `permission_role` VALUES (11, 117);
INSERT INTO `permission_role` VALUES (11, 118);
INSERT INTO `permission_role` VALUES (11, 121);
INSERT INTO `permission_role` VALUES (11, 123);
INSERT INTO `permission_role` VALUES (11, 129);
INSERT INTO `permission_role` VALUES (11, 130);
INSERT INTO `permission_role` VALUES (11, 131);
INSERT INTO `permission_role` VALUES (11, 132);
INSERT INTO `permission_role` VALUES (11, 133);
INSERT INTO `permission_role` VALUES (11, 134);
INSERT INTO `permission_role` VALUES (11, 135);
INSERT INTO `permission_role` VALUES (11, 136);
INSERT INTO `permission_role` VALUES (11, 137);
INSERT INTO `permission_role` VALUES (11, 138);
INSERT INTO `permission_role` VALUES (11, 139);
INSERT INTO `permission_role` VALUES (12, 113);
INSERT INTO `permission_role` VALUES (12, 117);
INSERT INTO `permission_role` VALUES (1, 140);
INSERT INTO `permission_role` VALUES (1, 141);
INSERT INTO `permission_role` VALUES (1, 142);
INSERT INTO `permission_role` VALUES (1, 143);
INSERT INTO `permission_role` VALUES (1, 144);
INSERT INTO `permission_role` VALUES (1, 145);
INSERT INTO `permission_role` VALUES (1, 146);
INSERT INTO `permission_role` VALUES (1, 147);
INSERT INTO `permission_role` VALUES (1, 148);
INSERT INTO `permission_role` VALUES (13, 113);
INSERT INTO `permission_role` VALUES (13, 117);
INSERT INTO `permission_role` VALUES (13, 147);
INSERT INTO `permission_role` VALUES (12, 147);
INSERT INTO `permission_role` VALUES (11, 147);
INSERT INTO `permission_role` VALUES (11, 148);
INSERT INTO `permission_role` VALUES (1, 149);
INSERT INTO `permission_role` VALUES (1, 150);
INSERT INTO `permission_role` VALUES (12, 149);
INSERT INTO `permission_role` VALUES (11, 149);
INSERT INTO `permission_role` VALUES (11, 150);
INSERT INTO `permission_role` VALUES (1, 151);
INSERT INTO `permission_role` VALUES (1, 152);
INSERT INTO `permission_role` VALUES (1, 153);
INSERT INTO `permission_role` VALUES (11, 151);
INSERT INTO `permission_role` VALUES (11, 152);
INSERT INTO `permission_role` VALUES (11, 153);
INSERT INTO `permission_role` VALUES (12, 151);
INSERT INTO `permission_role` VALUES (12, 152);
INSERT INTO `permission_role` VALUES (12, 153);
INSERT INTO `permission_role` VALUES (14, 149);
INSERT INTO `permission_role` VALUES (14, 117);
INSERT INTO `permission_role` VALUES (14, 150);
INSERT INTO `permission_role` VALUES (14, 113);
INSERT INTO `permission_role` VALUES (15, 113);
INSERT INTO `permission_role` VALUES (15, 117);
INSERT INTO `permission_role` VALUES (15, 147);
INSERT INTO `permission_role` VALUES (15, 148);
INSERT INTO `permission_role` VALUES (15, 149);
INSERT INTO `permission_role` VALUES (15, 150);
INSERT INTO `permission_role` VALUES (15, 151);
INSERT INTO `permission_role` VALUES (15, 152);
INSERT INTO `permission_role` VALUES (15, 153);
INSERT INTO `permission_role` VALUES (1, 154);
INSERT INTO `permission_role` VALUES (1, 155);
INSERT INTO `permission_role` VALUES (1, 156);
INSERT INTO `permission_role` VALUES (1, 157);
INSERT INTO `permission_role` VALUES (1, 158);
INSERT INTO `permission_role` VALUES (1, 159);
INSERT INTO `permission_role` VALUES (1, 160);
INSERT INTO `permission_role` VALUES (1, 161);
INSERT INTO `permission_role` VALUES (11, 154);
INSERT INTO `permission_role` VALUES (11, 155);
INSERT INTO `permission_role` VALUES (11, 156);
INSERT INTO `permission_role` VALUES (11, 157);
INSERT INTO `permission_role` VALUES (11, 158);
INSERT INTO `permission_role` VALUES (11, 159);
INSERT INTO `permission_role` VALUES (11, 160);
INSERT INTO `permission_role` VALUES (11, 161);
INSERT INTO `permission_role` VALUES (14, 154);
INSERT INTO `permission_role` VALUES (14, 156);
INSERT INTO `permission_role` VALUES (14, 157);
INSERT INTO `permission_role` VALUES (14, 159);
INSERT INTO `permission_role` VALUES (15, 154);
INSERT INTO `permission_role` VALUES (15, 156);
INSERT INTO `permission_role` VALUES (15, 157);
INSERT INTO `permission_role` VALUES (15, 159);
INSERT INTO `permission_role` VALUES (13, 154);
INSERT INTO `permission_role` VALUES (13, 155);
INSERT INTO `permission_role` VALUES (13, 156);
INSERT INTO `permission_role` VALUES (13, 157);
INSERT INTO `permission_role` VALUES (13, 158);
INSERT INTO `permission_role` VALUES (13, 159);
INSERT INTO `permission_role` VALUES (13, 160);
INSERT INTO `permission_role` VALUES (13, 161);
INSERT INTO `permission_role` VALUES (13, 149);
INSERT INTO `permission_role` VALUES (13, 150);
INSERT INTO `permission_role` VALUES (12, 150);
INSERT INTO `permission_role` VALUES (1, 162);
INSERT INTO `permission_role` VALUES (1, 163);
INSERT INTO `permission_role` VALUES (11, 162);
INSERT INTO `permission_role` VALUES (11, 163);
INSERT INTO `permission_role` VALUES (13, 148);
INSERT INTO `permission_role` VALUES (13, 151);
INSERT INTO `permission_role` VALUES (13, 152);
INSERT INTO `permission_role` VALUES (13, 153);
INSERT INTO `permission_role` VALUES (13, 163);
INSERT INTO `permission_role` VALUES (14, 162);
INSERT INTO `permission_role` VALUES (15, 162);
INSERT INTO `permission_role` VALUES (1, 164);
INSERT INTO `permission_role` VALUES (1, 165);
INSERT INTO `permission_role` VALUES (1, 166);
INSERT INTO `permission_role` VALUES (1, 167);
INSERT INTO `permission_role` VALUES (1, 168);
INSERT INTO `permission_role` VALUES (13, 164);
INSERT INTO `permission_role` VALUES (13, 165);
INSERT INTO `permission_role` VALUES (13, 166);
INSERT INTO `permission_role` VALUES (13, 167);
INSERT INTO `permission_role` VALUES (13, 168);
INSERT INTO `permission_role` VALUES (14, 164);
INSERT INTO `permission_role` VALUES (14, 165);
INSERT INTO `permission_role` VALUES (14, 166);
INSERT INTO `permission_role` VALUES (14, 167);
INSERT INTO `permission_role` VALUES (14, 168);
INSERT INTO `permission_role` VALUES (15, 164);
INSERT INTO `permission_role` VALUES (15, 165);
INSERT INTO `permission_role` VALUES (15, 166);
INSERT INTO `permission_role` VALUES (15, 167);
INSERT INTO `permission_role` VALUES (15, 168);
INSERT INTO `permission_role` VALUES (11, 164);
INSERT INTO `permission_role` VALUES (11, 165);
INSERT INTO `permission_role` VALUES (11, 166);
INSERT INTO `permission_role` VALUES (11, 167);
INSERT INTO `permission_role` VALUES (11, 168);
INSERT INTO `permission_role` VALUES (12, 157);
INSERT INTO `permission_role` VALUES (12, 159);
INSERT INTO `permission_role` VALUES (12, 164);
INSERT INTO `permission_role` VALUES (14, 153);
INSERT INTO `permission_role` VALUES (12, 148);
INSERT INTO `permission_role` VALUES (1, 169);
INSERT INTO `permission_role` VALUES (1, 170);
INSERT INTO `permission_role` VALUES (12, 169);
INSERT INTO `permission_role` VALUES (12, 170);
INSERT INTO `permission_role` VALUES (13, 169);
INSERT INTO `permission_role` VALUES (13, 170);
INSERT INTO `permission_role` VALUES (16, 3);
INSERT INTO `permission_role` VALUES (16, 4);
INSERT INTO `permission_role` VALUES (16, 5);
INSERT INTO `permission_role` VALUES (16, 6);
INSERT INTO `permission_role` VALUES (16, 7);
INSERT INTO `permission_role` VALUES (16, 8);
INSERT INTO `permission_role` VALUES (16, 9);
INSERT INTO `permission_role` VALUES (16, 10);
INSERT INTO `permission_role` VALUES (16, 11);
INSERT INTO `permission_role` VALUES (16, 2);

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 171 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES (1, 'dashboard', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (2, 'role_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (3, 'role_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (4, 'role_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (5, 'role_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (6, 'role_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (7, 'user_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (8, 'user_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (9, 'user_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (10, 'user_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (11, 'user_delete', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for role_user
-- ----------------------------
DROP TABLE IF EXISTS `role_user`;
CREATE TABLE `role_user`  (
  `user_id` int UNSIGNED NOT NULL,
  `role_id` int UNSIGNED NOT NULL,
  INDEX `user_id_fk_476171`(`user_id` ASC) USING BTREE,
  INDEX `role_id_fk_476171`(`role_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_user
-- ----------------------------
INSERT INTO `role_user` VALUES (1, 1);
INSERT INTO `role_user` VALUES (8, 12);
INSERT INTO `role_user` VALUES (1, 11);
INSERT INTO `role_user` VALUES (1, 12);
INSERT INTO `role_user` VALUES (4, 11);
INSERT INTO `role_user` VALUES (3, 12);
INSERT INTO `role_user` VALUES (5, 12);
INSERT INTO `role_user` VALUES (6, 12);
INSERT INTO `role_user` VALUES (7, 12);
INSERT INTO `role_user` VALUES (9, 12);
INSERT INTO `role_user` VALUES (10, 13);
INSERT INTO `role_user` VALUES (11, 13);
INSERT INTO `role_user` VALUES (12, 11);
INSERT INTO `role_user` VALUES (13, 13);
INSERT INTO `role_user` VALUES (14, 13);
INSERT INTO `role_user` VALUES (15, 13);
INSERT INTO `role_user` VALUES (16, 13);
INSERT INTO `role_user` VALUES (17, 14);
INSERT INTO `role_user` VALUES (18, 15);
INSERT INTO `role_user` VALUES (19, 13);
INSERT INTO `role_user` VALUES (20, 13);
INSERT INTO `role_user` VALUES (21, 13);
INSERT INTO `role_user` VALUES (22, 13);
INSERT INTO `role_user` VALUES (23, 13);
INSERT INTO `role_user` VALUES (24, 13);
INSERT INTO `role_user` VALUES (25, 13);
INSERT INTO `role_user` VALUES (26, 12);
INSERT INTO `role_user` VALUES (27, 12);
INSERT INTO `role_user` VALUES (28, 12);
INSERT INTO `role_user` VALUES (29, 12);
INSERT INTO `role_user` VALUES (30, 12);
INSERT INTO `role_user` VALUES (31, 12);
INSERT INTO `role_user` VALUES (32, 12);
INSERT INTO `role_user` VALUES (33, 12);
INSERT INTO `role_user` VALUES (34, 12);
INSERT INTO `role_user` VALUES (35, 12);
INSERT INTO `role_user` VALUES (36, 12);
INSERT INTO `role_user` VALUES (37, 12);
INSERT INTO `role_user` VALUES (2, 12);
INSERT INTO `role_user` VALUES (38, 13);
INSERT INTO `role_user` VALUES (39, 12);
INSERT INTO `role_user` VALUES (40, 12);
INSERT INTO `role_user` VALUES (41, 12);
INSERT INTO `role_user` VALUES (42, 12);
INSERT INTO `role_user` VALUES (43, 12);
INSERT INTO `role_user` VALUES (44, 12);
INSERT INTO `role_user` VALUES (45, 12);
INSERT INTO `role_user` VALUES (46, 12);
INSERT INTO `role_user` VALUES (47, 12);
INSERT INTO `role_user` VALUES (48, 13);
INSERT INTO `role_user` VALUES (49, 13);
INSERT INTO `role_user` VALUES (50, 13);
INSERT INTO `role_user` VALUES (51, 13);
INSERT INTO `role_user` VALUES (52, 12);
INSERT INTO `role_user` VALUES (53, 12);
INSERT INTO `role_user` VALUES (54, 12);
INSERT INTO `role_user` VALUES (56, 16);
INSERT INTO `role_user` VALUES (58, 1);

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, 'Admin', NULL, NULL, NULL);
INSERT INTO `roles` VALUES (16, 'Default', '2025-08-11 09:56:43', '2025-08-11 12:20:26', NULL);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_login` datetime NULL DEFAULT NULL,
  `ip_address` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '127.0.0.1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_email_unique`(`email` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'Super Admin', 'admin@admin.com', '$2y$10$xAfrO6m5H1xTGNklFPfrVey1wDbBATqFuxLBJo2giM900eBjJQcX.', '2023-01-03 20:28:44', '127.0.0.1', '2020-05-18 17:07:15', '2023-02-06 02:53:20');
INSERT INTO `users` VALUES (58, 'test', 'test@tes.com', '$2y$10$fKuROFxfPk/JNsiXf5JI/OByXy36rzlBLAoncC3FbPsNGqWjyi2Pq', NULL, '127.0.0.1', '2025-08-11 12:16:27', '2025-08-11 12:16:27');

SET FOREIGN_KEY_CHECKS = 1;
